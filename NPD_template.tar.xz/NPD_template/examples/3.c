#include<stdio.h>
#include<stdlib.h>

struct a {
  int f1;
  struct b * f2;
};

struct b {
  char f1;
};

struct a astruct;
struct a * aptr = &astruct;

int main() {

  if (aptr->f1 == 43) {
    return 2;
  }

  if (aptr->f2[0].f1 == 25) {
    return 3;
  }
  
  return 0;
}