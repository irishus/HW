#include<stdio.h>
#include<stdlib.h>

int * foo(int * ptrarg) {
  return ptrarg + 1;
}

int main() {

  int * intptr = malloc(sizeof(int) * 100);
  int * orig_ptr = intptr;

  *intptr = 23; 

  char * charptr = malloc(sizeof(char) * 128);

  *charptr = -5;

  *foo(intptr) = 102;

  int intarr[10][10];

  **intarr = 42;

  free(orig_ptr);

  int * nullptr = 0;
  *nullptr = 243;
  
  return 0;
}