#include<stdio.h>
#include<stdlib.h>

int main() {
    int * intptr1 = malloc(sizeof(int) * 2);
    int * intptr2 = malloc(sizeof(int) * 2);
    int * intptr3 = malloc(sizeof(int) * 2);

    intptr1[1] = intptr2[1] = intptr3[1] = 243;

    int * intptr4 = 0;

    intptr4[0] = 243;
}